
public class NormalRod extends Rod{

	public NormalRod(String name, String brand, int length, int successRate) {
		super(name, brand, length, successRate);
	}
	
}
